sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("com.acme.incidentmanagement.incidents.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);